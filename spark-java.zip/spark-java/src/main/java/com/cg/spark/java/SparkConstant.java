package com.cg.spark.java;

public class SparkConstant {
	
	public static final String MASTER_LOCAL = "local";
	public static final String APP_NAME = "SPARK";

}
